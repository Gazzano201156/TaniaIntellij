package Model;

public class Cliente {
}
