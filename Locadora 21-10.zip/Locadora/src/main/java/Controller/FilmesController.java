package Controller;
import Repository.FilmeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/apiFilme")

public class FilmesController {


    @Autowired
    FilmeRepository filmeRepository;



    @GetMapping(value ="/Filmes")
    public List <Filmes> listarFilmes()
    {
        return filmeRepository.findAll();

    }


    private String genero;
    private String titulo;
    private int codigo;


    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
}
