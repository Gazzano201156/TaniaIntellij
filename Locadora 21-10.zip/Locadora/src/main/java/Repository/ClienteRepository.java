package Repository;

public class ClienteRepository {
}
